- Instalar dependencias com o comando:
```bash
python -m pip install -r requirements.txt
```
- Iniciar aplicacao com:
```bash
python3 manage.py migrate
python3 manage.py runserver
```
