from django.contrib import admin
from .models import Contact, User, Address

admin.site.register(Contact)
admin.site.register(User)
admin.site.register(Address)